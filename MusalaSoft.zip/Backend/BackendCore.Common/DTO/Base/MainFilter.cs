﻿namespace BackendCore.Common.DTO.Base
{
    public class MainFilter
    {
        public string Name { get; set; }
    }
}
