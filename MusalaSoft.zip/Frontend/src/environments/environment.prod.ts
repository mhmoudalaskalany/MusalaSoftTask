export const environment = {
  state: 'production'
};
