export class SortModel {
  colId = '';
  sort = '';
}
