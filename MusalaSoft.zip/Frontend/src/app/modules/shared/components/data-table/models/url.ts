export interface URL {
  getAll?: string;
  delete?: string;
}
