export class LoginModel {
    userName?: string;
    password?: string;
}
