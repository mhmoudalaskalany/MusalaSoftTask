import { Injector } from '@angular/core';

export class Shell {
  // injector to get instance of services without constructor injection
  public static Injector: Injector;
}
