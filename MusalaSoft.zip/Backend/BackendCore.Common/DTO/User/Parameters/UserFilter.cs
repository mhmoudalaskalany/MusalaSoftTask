﻿using BackendCore.Common.DTO.Base;

namespace BackendCore.Common.DTO.User.Parameters
{
    public class UserFilter : MainFilter
    {
        public string Username { get; set; }
    }
}
