export const environment = {
  state: 'staging'
};
